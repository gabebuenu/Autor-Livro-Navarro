﻿using System.ComponentModel.DataAnnotations;

namespace Biblioteca.Model
{
    public class Autor
    {
        [Key]
        public int Id { get; set; }
        public string Nome { get; set; }

        public Autor(string nome)
        {
            Nome = nome;
        }
    }
}

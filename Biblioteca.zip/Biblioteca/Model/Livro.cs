﻿using System.ComponentModel.DataAnnotations;

namespace Biblioteca.Model
{
    public class Livro
    {
        [Key]
        public int Id { get; set; }
        public string Nome { get; set; }
        public int AutorId { get; set; }
        public Autor Autor { get; set; }

        public Livro(string nome, int autorId)
        {
            Nome = nome;
            AutorId = autorId;
        }
    }
}

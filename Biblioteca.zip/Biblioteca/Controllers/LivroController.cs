﻿using System.Linq;
using Biblioteca.Context;
using Biblioteca.DTO;
using Biblioteca.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Biblioteca.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LivroController : ControllerBase
    {
        private readonly DataContext _dataContext;

        public LivroController()
        {
            _dataContext = new DataContext();
        }

        // GET: api/<LivroController>
        [HttpGet]
        public ActionResult<List<Livro>> Get()
        {
            var livros = _dataContext.Livro.ToList<Livro>();
            return livros;
        }

        // GET api/<LivroController>/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/<LivroController>
        [HttpPost]
        public ActionResult<Livro> Post([FromBody] LivroRequest livroRequest)
        {
            if (ModelState.IsValid)
            {
                var livro = livroRequest.ToModel();
                _dataContext.Livro.Add(livro);
                _dataContext.SaveChanges();
                return livro;
            }
            return BadRequest(ModelState);
        }

        // PUT api/<LivroController>/5
        [HttpPut]
        public ActionResult<Livro> Put([FromBody] Livro livro)
        {
            var livroENulo = _dataContext.Livro.FirstOrDefault(livro) == null;
            if (livroENulo)
                ModelState.AddModelError("LivroId", "Id do livro não encontrado!");

            if (ModelState.IsValid)
            {
                _dataContext.Livro.Update(livro);
                _dataContext.SaveChanges();
                return livro;
            }
            return BadRequest(ModelState);

        }

        // DELETE api/<LivroController>/5
        [HttpDelete("{id}")]
        public ActionResult Delete(int id)
        {
            var livro = _dataContext.Livro.Find(id);
            if (livro == null)
                ModelState.AddModelError("LivroId", "Id do livro não encontrado!");

            if (ModelState.IsValid)
            {
                _dataContext.Livro.Remove(livro);
                _dataContext.SaveChanges();
                return Ok();
            }
            return BadRequest(ModelState);
        }
    }
}

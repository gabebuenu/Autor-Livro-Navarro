﻿using Biblioteca.Context;
using Biblioteca.DTO;
using Biblioteca.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Biblioteca.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AutorsController : ControllerBase
    {

        private readonly DataContext _dataContext;

        public AutorsController()
        {
            _dataContext = new DataContext();
        }

        // GET: api/<AutorsController>
        [HttpGet]
        public ActionResult<List<Autor>> Get()
        {
            return _dataContext.Autor.ToList();

        }

        // GET api/<AutorsController>/5
        [HttpGet("{id}")]
        public ActionResult<Autor> Get(int id)
        {
            var autor = _dataContext.Autor.FirstOrDefault(x => x.Id == id);
            if (autor == null)
            {
                return BadRequest("ID não existente");
            }
            return autor;
        }

        // POST api/<AutorsController>
        [HttpPost]
        public ActionResult<Autor> Post([FromBody] AutorRequest autorRequest)
        {
            if (ModelState.IsValid)
            {
                var autor = autorRequest.toModel();
                _dataContext.Autor.Add(autor);
                _dataContext.SaveChanges();
                return autor;
            }
            return BadRequest(ModelState);
        }

        // PUT api/<AutorsController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<AutorsController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}

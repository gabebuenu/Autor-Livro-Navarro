﻿using Biblioteca.Context;
using Biblioteca.DTO;
using Biblioteca.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Biblioteca.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AutorController : ControllerBase
    {
        private readonly DataContext _dataContext;

        public AutorController()
        {
            _dataContext = new DataContext();
        }

        // GET: api/<AutorController>
        [HttpGet]
        public ActionResult<List<Autor>> Get()
        {
            var autors = _dataContext.Autor.ToList<Autor>();
            return autors;
        }

        // GET api/<AutorController>/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/<AutorController>
        [HttpPost]
        public ActionResult<Autor> Post([FromBody] AutorRequest autorRequest)
        {
            if (ModelState.IsValid)
            {
                var autor = autorRequest.toModel();
                _dataContext.Autor.Add(autor);
                _dataContext.SaveChanges();
                return autor;
            }
            return BadRequest(ModelState);
        }

        // PUT api/<AutorController>/5
        [HttpPut]
        public ActionResult<Autor> Put([FromBody] Autor autor)
        {
            var autorENulo = _dataContext.Autor.FirstOrDefault(autor) == null;
            if (autorENulo)
                ModelState.AddModelError("AutorId", "Id do autor não encontrado!");

            if (ModelState.IsValid)
            {
                _dataContext.Autor.Update(autor);
                _dataContext.SaveChanges();
                return autor;
            }
            return BadRequest(ModelState);

        }

        // DELETE api/<AutorController>/5
        [HttpDelete("{id}")]
        public ActionResult Delete(int id)
        {
            var autor = _dataContext.Autor.Find(id);
            if (autor == null)
                ModelState.AddModelError("AutorId", "Id do autor não encontrado!");

            if (ModelState.IsValid)
            {
                _dataContext.Autor.Remove(autor);
                _dataContext.SaveChanges();
                return Ok();
            }
            return BadRequest(ModelState);
        }
    }
}

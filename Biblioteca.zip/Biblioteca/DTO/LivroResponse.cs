﻿using Biblioteca.Model;

namespace Biblioteca.DTO
{
    public class LivroResponse
    {
        public string Nome { get; set; }
        public Autor Autor { get; set; }

        public LivroResponse(Livro livro)
        {
            Nome = livro.Nome;
            Autor = livro.Autor;
        }
    }
}

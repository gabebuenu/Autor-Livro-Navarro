﻿using System.ComponentModel.DataAnnotations;
using Biblioteca.Model;

namespace Biblioteca.DTO
{
        public class AutorRequest
        {
            [MinLength(3)]
            public string Nome { get; set; }

            public Autor toModel()
                => new Autor(Nome);
        }

}

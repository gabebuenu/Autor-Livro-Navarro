﻿using System.ComponentModel.DataAnnotations;
using Biblioteca.Model;

namespace Biblioteca.DTO
{
    public class LivroRequest
    {
        [MinLength(3)]
        public string Nome { get; set; }
        [Required]
        public int AutorId { get; set; }

        public Livro ToModel()
            => new Livro(Nome, AutorId);

    }
}
